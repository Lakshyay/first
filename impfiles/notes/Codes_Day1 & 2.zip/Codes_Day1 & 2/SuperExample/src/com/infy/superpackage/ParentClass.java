package com.infy.superpackage;

public class ParentClass {

	int a = 10;
	
	ParentClass()
	{
		System.out.println("Constructor in ParentClass");
	}
	
 void method() 
	{   
		System.out.println("Method in ParentClass");
	}
}
