package com.infy.superpackage;

public class ChildClass extends ParentClass {
	  int a = 20;
	 
	 ChildClass()
	 {
		 super(); // Invokes a constructor from parent class
		 System.out.println("Constructor in ChildClass");
	 }
	 
	 @Override
	 void method()
		{
			System.out.println("Method in ChildClass");
		}

	 void display()
	 { 
		 System.out.println("Value of a in ParentClass : "+super.a); // Access variable from parent class
		 System.out.println("Value of a in ChildClass : "+a); // Access variable from child class
		 super.method(); // Invokes method from parent class
		 method();       // Invokes method from child class
	 }
	 
}
