package com.infy.superpackage;

public class MainClass {

	public static void main(String[] args) {
		ChildClass ob = new ChildClass();
		ob.display();

	}

}
