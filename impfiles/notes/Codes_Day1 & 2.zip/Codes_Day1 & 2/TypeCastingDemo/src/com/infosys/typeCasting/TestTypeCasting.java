package com.infosys.typeCasting;

public class TestTypeCasting {

	public static void main(String[] args) {
//		double d = 344.04; 
//		long l = (long)d; //explicit type casting 
//		int i = (int)l; // explicit type casting 
//		System.out.println("double value :"+d);
//		System.out.println("long value :"+l); 
//		System.out.println("int value :"+i);
		
		int x = 130;
		byte y = (byte)x;
		System.out.println("int value :"+x);
		System.out.println("Byte value :"+y); //Loss of data
	      
	      
			
//			  int i = 475; 
//			  long l = i; //implicit type casting 
//			  float f = l; //implicit type casting 
//			  System.out.println("int value :"+i);
//			  System.out.println("long value :"+l); 
//			  System.out.println("float value :"+f);
			 
	}

}
