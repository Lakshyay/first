package com.infy.inheritance;

public class CricketPlayer extends Player{

	int runs;
	int wickets;
	public int getRuns() {
		return runs;
	}
	public void setRuns(int runs) {
		this.runs = runs;
	}
	public int getWickets() {
		return wickets;
	}
	public void setWickets(int wickets) {
		this.wickets = wickets;
	}
	
	
	
	public void display()    // Overriding Method
	{
		System.out.println("Display method in CricketPlayer class");
		
	}
}
