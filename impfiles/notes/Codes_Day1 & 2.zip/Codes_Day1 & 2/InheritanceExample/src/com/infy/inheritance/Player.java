package com.infy.inheritance;

public class Player {
String name;
String teamName;
int age;
int matches;


public String getName() {
	return name;
}
 public void setName(String name) {
	this.name = name;
}
public String getTeamName() {
	return teamName;
}
public void setTeamName(String teamName) {
	this.teamName = teamName;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public int getMatches() {
	return matches;
}
public void setMatches(int matches) {
	this.matches = matches;
}


public void display()   //This method is overridden in child classes
{
	System.out.println("Display method in Player class");
}



}
