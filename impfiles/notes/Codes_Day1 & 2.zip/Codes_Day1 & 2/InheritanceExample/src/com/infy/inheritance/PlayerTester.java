package com.infy.inheritance;

public class PlayerTester {

	public static void main(String[] args) {
		CricketPlayer c = new CricketPlayer();
		FootballPlayer f = new FootballPlayer();
		
	
		c.setName("Sachin");
		c.setTeamName("India");
		c.setAge(40);
		c.setMatches(375);
		c.setRuns(30000);
		c.setWickets(250);
		
		System.out.println("*********Information of Cricket Player*********");
		System.out.println("Name: "+c.getName());
        System.out.println("Team Name: "+c.getTeamName());
        System.out.println("Age: "+c.getAge());
        System.out.println("Number of matches played: "+c.getMatches());
        System.out.println("Number of runs: "+c.getRuns());
        System.out.println("Number of wickets: "+c.getWickets());
		
        
        f.setName("Ronaldo");
		f.setTeamName("Portugal");
		f.setAge(38);
		f.setMatches(200);
		f.setGoals(300);
				
		System.out.println("\n\n*********Information of Football Player*********");
		System.out.println("Name: "+f.getName());
        System.out.println("Team Name: "+f.getTeamName());
        System.out.println("Age: "+f.getAge());
        System.out.println("Number of matches played: "+f.getMatches());
        System.out.println("Number of goals: "+f.getGoals());
        
        
        Player p = new Player();
        p.display();   // Calling overridden method (from parent class)
        
        p = new CricketPlayer();
        p.display();  // Calling overriding method (from child class)

        p = new FootballPlayer();
        p.display();  // Calling overriding method (from child class)
	}

}
