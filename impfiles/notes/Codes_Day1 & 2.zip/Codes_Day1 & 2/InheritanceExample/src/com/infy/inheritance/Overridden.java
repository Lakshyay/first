package com.infy.inheritance;

public @interface Overridden {

}
