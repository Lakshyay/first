package com.infy.inheritance;

public class FootballPlayer extends Player {
	int goals;

	public int getGoals() {
		return goals;
	}

	public void setGoals(int goals) {
		this.goals = goals;
	}
	
	public void display()   // Overriding Method
	{
		System.out.println("Display method in FootballPlayer class");
	}
}
