package com.infy.array;

//import java.util.Scanner;

public class ArrayOfIntegers {
	public static void main(String[] args) {
		int marks[] = {75, 24, 54, 45, 40, 78, 39, 80, 32, 45};
		
//		Scanner ob = new Scanner(System.in);
//		int marks[] = new int [5];
//      System.out.println("Enter marks of 5 students:");				
//		for(int j=0;j<marks.length;j++)
//			marks[j]=ob.nextInt();
		
		int passed=0,failed=0;
//	    for(int i=0;i<marks.length;i++)
//	     if(marks[i]>=40)
//	    	 passed++;
//	     else
//	    	 failed++;
//	    
//        System.out.println("The Number of Students Passed in the Exam = "+passed);
//        System.out.println("The Number of Students Failed in the Exam = "+failed);
        
       
        
        for(int m:marks)
   	     if(m >= 40)
   	    	 passed++;
   	     else
   	    	 failed++;
   	    
           System.out.println("The Number of Students Passed in the Exam = "+passed);
           System.out.println("The Number of Students Failed in the Exam = "+failed);
        
        	}
}
