package com.infosys.classobject;

public class StudentInfoTester {

	public static void main(String[] args) {
		
		
		StudentInfo s1=new StudentInfo();
		
//		s1.setStudentID(10);
//		s1.setName("Sachin");
//		s1.setMarks(52.23f);
		
		System.out.println("\n*****Information of Student 1*****");
		System.out.println("Student ID: "+s1.getStudentID());
		System.out.println("Name: "+s1.getName());
		System.out.println("Marks: "+s1.getMarks());
		
		//StudentInfo s2=new StudentInfo();
		StudentInfo s2=new StudentInfo(20, "Vijay", 62.35f);
		System.out.println("\n*****Information of Student 2*****");
		System.out.println("Student ID: "+s2.getStudentID());
		System.out.println("Name: "+s2.getName());
		System.out.println("Marks: "+s2.getMarks());
	}

}
