package com.infosys.classobject;

public class StudentInfo {
	private	int studentID;
	private String name;
	private float marks;
	
public StudentInfo() {
	System.out.println("I am in Default constructor");
	this.studentID=1;
	this.name="DemoStudent";
	this.marks=0.0f;
}
        
public StudentInfo(int studentID, String name, float marks) {
	System.out.println("\nI am in Parameterized constructor");
	this.studentID=studentID;
	this.name=name;
	this.marks=marks;
}

//public void setStudentID(int studentID)
//{
//	this.studentID=studentID;
//}
//
//public void setName(String nm)
//{
//	name=nm;
//}
//
//public void setMarks(float m)
//{
//	marks=m;
//}

public int getStudentID()
{
	return(studentID);
}

public String getName()
{
	return(name);
}

public float getMarks()
{
	return(marks); 
}

}
