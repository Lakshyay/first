package com.infy.staticdemo;

public class Demo{
static int x = 10;
	static void method()
	{   
		System.out.println("\nStatic method in Demo class");
	}
	
	static  //Static block is executed only once, not for every object
	{
		System.out.println("Static Block");
	}
}
