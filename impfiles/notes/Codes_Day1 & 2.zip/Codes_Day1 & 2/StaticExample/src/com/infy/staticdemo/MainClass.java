package com.infy.staticdemo;

public class MainClass {

	public static void main(String[] args) {
		Demo ob1 = new Demo(); //Static block is executed only once
		Demo ob2 = new Demo();
		Demo ob3 = new Demo();

		System.out.println("\nValue of x for ob1 = "+ob1.x); // see the warning message
		System.out.println("Value of x for ob2 = "+ob2.x);
		System.out.println("Value of x for ob3 = "+ob3.x);
		
		System.out.println("\nValue of x for ob1 = "+Demo.x); //proper way of accessing static member
		System.out.println("Value of x for ob2 = "+Demo.x);
		System.out.println("Value of x for ob3 = "+Demo.x);
		
		Demo.method(); //proper way of accessing static member
		ob1.method(); // see the warning message
	}

}
