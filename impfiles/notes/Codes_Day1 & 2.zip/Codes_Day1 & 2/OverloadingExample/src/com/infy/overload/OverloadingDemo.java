package com.infy.overload;

public class OverloadingDemo {
	
	public void add(int a,int b) {
		System.out.println("Addition of " +a+ " and " +b+ " = "+(a+b));
	}
	
	public void add(float a, float b) {
		System.out.println("Addition of " +a+ " and " +b+ " = "+(a+b));
	}
	
	public void add(String s1, String s2) {
		System.out.println(s1.concat(s2));
	}
	
	public static void main(String args[]) {
		OverloadingDemo ob = new OverloadingDemo();
		ob.add(5,10);
		ob.add(1.5f, 3.2f);
		ob.add("Sachin", "Tendulakar");
	}

}
