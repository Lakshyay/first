
public class Child2 extends Parent{
	int e;
	int f;
	Child2(int a, int b,  int e, int f)
	{
		super(a,b);
		this.e = e;
		this.f = f;
	}
	
	void display2()
	{
		System.out.println("a ="+a+" b="+b+" e="+e+" f="+f);
	}
}
