
public class Child1 extends Parent{
	int c;
	int d;
	Child1(int a, int b, int c, int d)
	{
		super(a,b);
		this.c = c;
		this.d = d;
	}
	
	void display1()
	{
		System.out.println("a ="+a+" b="+b+" c="+c+" d="+d);
	}

}
