
public class Parent {
 int a;
 int b;
 
 Parent (int a, int b)
 {
	 this.a = a;
	 this.b = b;
 }
}
