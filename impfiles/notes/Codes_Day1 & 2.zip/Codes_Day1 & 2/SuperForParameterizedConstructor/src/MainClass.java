
public class MainClass {

	public static void main(String[] args) {
		Child1 ob1 = new Child1(1,2,3,4);
		Child2 ob2 = new Child2(5,6,7,8);
		ob1.display1();
		ob2.display2();

	}

}
