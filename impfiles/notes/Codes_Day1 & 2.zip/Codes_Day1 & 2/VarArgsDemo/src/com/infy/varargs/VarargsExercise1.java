package com.infy.varargs;

//import javax.print.attribute.IntegerSyntax;

public class VarargsExercise1 {

		public void displayList(int...input)
		{
			System.out.print("\nThe values in a list are: ");
			for(int i:input)
			System.out.print(i+" ");
		}

	
		public void maxOfList(int...input)
		{
			int max=input[0];
			for(int i:input)
			if(i>max)
			max=i;

			System.out.println("\nMaximum of list =  "+max);
		}
		
		public void sortList(int...input)
		{
			int temp;
			for(int i=0;i<input.length-1;i++)
				for(int j=i+1;j<input.length;j++)
 					if(j<i)
					{
						temp=i;
						i=j;
						j=temp;
					}
			System.out.println("Sorted list in ascending order is:  ");

			for(int k:input)
			System.out.print(k+" ");
		}

		public void averageList(int...input)
		{
			int sum=0;
			for(int i:input)
			sum+=i;
			float avg=(sum)/input.length;
			System.out.println("\nAverage = "+avg);
		}

		public static void main(String[] args) 
		{
			VarargsExercise1 ob = new VarargsExercise1();
			
			ob.displayList(12,24,45);
			ob.maxOfList(12,24,45,35);
			ob.sortList(12,24,45,35);
			ob.averageList(12,24,45,35);
			
//			int a[] = {11,22,33};
//			ob.displayList(a);
			
			
			
		}

}
