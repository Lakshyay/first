package stringHandling;

class Student{
	int rollNo;
	String name;
	
	Student(int r, String n){
		rollNo=r;
		name = n;
			}
	public String toString() {
		return rollNo  +" " + name;
	}
}

public class TostringExample {
public static void main(String[] args) {
	Student s = new Student(1,"Ajay");
	Student s1 = new Student(2,"Poonam");
	System.out.println(s);
	System.out.println(s1);
}
}
