package stringHandling;

public class StringBufferEx {
	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer("kirti");
		sb.append("something");
		System.out.println(sb);
		sb.insert(1, "Java");
		System.out.println(sb);
		sb.replace(1, 4, "Cool");
		System.out.println(sb);
       
	}

}
