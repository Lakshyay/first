package stringHandling;

public class StringEx {
public static void main(String[] args) {
//	String str = "gagan";
//	String newname = str.concat("saraswat");
//	System.out.println(newname);
	
	String s1 = "manisha";
	String s2 ="manisha";
	String s3 = "sankar";
	String s = s1.concat("khurana");
	System.out.println(s);
	System.out.println(s.charAt(0));
	System.out.println(s1.equals(s2));
	System.out.println(s2.equals(s3)); 
	
}
}
