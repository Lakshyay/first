package stringHandling;

public class A {
public static void main(String[] args) {
	String s1 = new String("xyz");
	String s2 = new String("xyz");
	System.out.println(s1==s2);
	System.out.println(s1.equals(s2));//content
	
	String s3 = "ayushi";
	String s4 ="ayushi";
	String s5 = "xyz";
	String s6 ="xyz";
	
	System.out.println(s1==s5);
//	System.out.println(s5==s6);
	
}
}
