package staticModifier;

public class StaticClassEx {
static String str = "Have a nice day";

//static class
static class NestedClass{
	public void display() {
		System.out.println(str);
	}
	
}

public static void main(String[] args) {
	
	NestedClass ns = new NestedClass();
	ns.display();
}
}
