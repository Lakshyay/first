package staticModifier;

public class StaticVariableEx {
static int i = 2;
void display() {
	i++;
	System.out.println(i); 
	
}
public static void main(String[] args) {
	StaticVariableEx sv = new StaticVariableEx();
	sv.display();
	StaticVariableEx sv1 = new StaticVariableEx();
	sv1.display();
}
}
