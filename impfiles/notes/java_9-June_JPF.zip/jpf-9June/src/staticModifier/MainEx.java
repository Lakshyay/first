package staticModifier;

class Tester {
static void method1() {
	System.out.println("I am the first static method");
}
}

class Test2 extends Tester{
	static void method1() {
		System.out.println("I am overridingf the method1");
	}
}

public class MainEx{
	public static void main(String[] args) {
//		Tester t = new Tester();
//		t.method1();
		Test2.method1();
	}
}
