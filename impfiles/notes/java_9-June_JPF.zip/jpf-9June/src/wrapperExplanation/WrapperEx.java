package wrapperExplanation;

public class WrapperEx {
	public static void main(String[] args) {
//		Integer i = 10;//Boxing
//		int i1 = i;//unboxing.
		
	Integer i = new Integer(34);
	Integer i1 = 10;
	
	int i2 = i1.intValue();//unwrap primitive from wrapper.
	
	Integer intObj1 = new Integer(25);
	Integer intObj2 = new Integer(25);
	Integer intObj3 = new Integer(35);
	//compareTo
	System.out.println(intObj1.compareTo(intObj2));
	System.out.println(intObj1.compareTo(intObj3));
	
	
	//equals
//	System.out.println(intObj1.equals(intObj2));
//	System.out.println(intObj1.equals(intObj3));
//		
	
	Float f1 = new Float(2.25f);
	Float f2 = new Float(20.69f);
	Float f3 = new Float(2.50f);
	
	//compare
	System.out.println(Float.compare(f2, f1));
	System.out.println(Float.compare(f2, f3));
	}

}
