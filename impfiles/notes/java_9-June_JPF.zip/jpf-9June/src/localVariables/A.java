package localVariables;

public class A {
public static void main(String[] args) {
	int age=10;//local variable
	System.out.println(age);
	A a1 = new A();
	a1.test();
}
public void test() {
	int age = 20;
	System.out.println(age);
}
}
