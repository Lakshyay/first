package reference;

public class A {
public static void main(String[] args) {
//	A a1 = new A();//craeted
//	A a2 = a1;
//	System.out.println(a1);
//	System.out.println(a2);
	
	
}
public static void test() {
//	System.out.println(a1);
}
}
