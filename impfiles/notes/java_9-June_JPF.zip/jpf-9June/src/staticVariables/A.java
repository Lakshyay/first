package staticVariables;

public class A {
static int age;//global access
public static void main(String[] args) {
	System.out.println(age);
	A.test();
	test();
}
public static void test() {
	System.out.println(age);
}
}
