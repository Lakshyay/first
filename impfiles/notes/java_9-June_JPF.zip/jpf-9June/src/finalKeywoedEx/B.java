package finalKeywoedEx;

final public class B extends A {
//@Override
//public void test() {

}

