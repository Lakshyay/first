package finalKeywoedEx;

public class A {
//final static int x=10;
	final public void test() {
		System.out.println(100);
	}
	public static void main(String[] args) {
		A a1 = new A();
	}
	
	

}
