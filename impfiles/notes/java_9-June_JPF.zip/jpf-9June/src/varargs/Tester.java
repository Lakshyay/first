package varargs;

public class Tester {
	
		  public static void main(String[] args){
		    Employee employee1=new Employee("E1001");//creating employee class object
		    int rewardPoint=employee1.reward(100000,200000,300000); //calling reward method with arguments
		    
		    
		    Employee employee2=new Employee("E1002");
		    int rewardPoint1=employee2.reward(100000,100000);
		    
		    Employee employee3=new Employee("E1002");
		    int rewardPoint2=employee2.reward(100000,100000,500000,30000);
		    
		    Employee employee4 = new Employee("E1003");
		    int rewardPoint3 = employee4.reward(450000,654789,678700,567000,65400);
		    
		    Employee employee5 = new Employee("E1004");
		                 int rewardPoint4 = employee5.reward(564778);
		    
		    System.out.println(employee1.getEmployeeId() +" has got a reward of "+rewardPoint);
		    System.out.println(employee2.getEmployeeId() +" has got a reward of "+rewardPoint1);
		    System.out.println(employee3.getEmployeeId() +" has got a reward of "+rewardPoint2);
		    System.out.println(rewardPoint3);
		    System.out.println(rewardPoint4);
		  }
		
}
