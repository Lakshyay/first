package arrays;

public class Array {
	public static void main(String[] args) {
		int[] marks;//a way to create and declare array
        marks=new int[5];
        marks[0]=98;
        marks[1]=99;
        marks[2]=97;
        marks[3]=96;
        marks[4]=98;
        
        //or
        String mark[] = new String[5];
        
        //or
        int[] mark1 = {99,98,97,96,95};
         
        System.out.println(marks.length);
        
        //traverse
        for(int i =0; i<marks.length;i++) {
        	System.out.println("Marks of subject" +i +"is" + mark1[i]);
        }
        
        //traverse through foreach loop
        for(int i : marks )//enhaned for loop
        { System.out.println(i);
        }  // for each
        
   
	}

}
