package arrays;

public class TwoDArray {
	public static void main(String[] args) {
		int arr[]= {4,5,6};
		int[] arr2 = {8,9,7};

		int[][] twoDarr= {arr,arr2};
		int[][] arr4 = new int[3][5];

		//traverse
		//nested for loop

		for(int i = 0;i<twoDarr.length;i++) {
			for(int j = 0;j<twoDarr[i].length;j++) {
				System.out.print(" "+twoDarr[i][j]);
				
			}
			System.out.println();
		}
	}

}
