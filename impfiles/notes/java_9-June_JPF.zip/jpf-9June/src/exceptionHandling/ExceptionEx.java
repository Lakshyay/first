package exceptionHandling;

public class ExceptionEx {
public static void main(String[] args) {
	int i = 20;
//	int j = 0;
//	try {
//	int result = i/j;//halts.//execution stops over here.s
//	}catch(Exception e) {
//		System.out.println(e);
//	}
//	System.out.println("Hi");
//}
//	try {
//		int a[] = new int[5];
//		int b = a[6];
//	}catch(Exception e) {
//		System.out.println(e);
//	}
//	System.out.println("hwllo");
	
	try {
		String s = null;
		System.out.println(s.length());
	}catch(Exception e) {
		System.out.println(e);
	}
}
}
