package exceptionHandling;

public class Throwkeywordex {

	void validate(int age) {
		if(age<18) {
			throw new ArithmeticException("Person is not eligible to vote");
		}else {
			System.out.println("Person is eligible");
		}
	}
	public static void main(String[] args) {
		Throwkeywordex t = new Throwkeywordex();
		t.validate(15);
	}
	
}
