package exceptionHandling;

public class MultiTryEx {
public static void main(String[] args) {
	try {
		try {
			System.out.println("about to throw exception");
			int f = 13/0;
		}catch(ArithmeticException ae) {
			System.out.println(ae);
		}
		try {
			int a[]=new int[7];
			a[8]=6;
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}
	}catch(Exception e) {
		System.out.println("catch block of external try");
	}
}
}
