package exceptionHandling;

public class UserDefined {
public static void main(String[] args) throws InsufficientFunds {
	int bal = 500;
	int amount = 1200;
	if(bal>amount) {
		System.out.println("please collect cash");
	}else {
		try {
			throw new InsufficientFunds("Balance is low!");
		}catch(InsufficientFunds i) {
			System.out.println(i);
		}
	}
}
}
