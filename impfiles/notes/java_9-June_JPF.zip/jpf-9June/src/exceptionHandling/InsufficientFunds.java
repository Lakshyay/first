package exceptionHandling;

public class InsufficientFunds extends Exception{//parent class
	
    public InsufficientFunds(String message) {//throw keyword
        super(message);
    }
}
