package exceptionHandling;

import java.io.IOException;

public class ThrowsEx {

	void m() throws IOException{
		throw new IOException("some device error");
	}
	
	public static void main(String[] args) {
		ThrowsEx t = new ThrowsEx();
		try {
			t.m();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
}
