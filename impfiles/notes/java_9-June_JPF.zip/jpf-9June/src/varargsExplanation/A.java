package varargsExplanation;

public class A {
static void test(int... numbers) {
	System.out.println("Length of varargs :"+numbers.length);
	
	for(int i : numbers) {
		System.out.println(" "+ i);
		
	}
	
}
public static void main(String[] args) {
	test();
	test(32,56,67);
	test(56,87,98,76,78);
	test(67,8,8,9,7,8,9);
}
}
