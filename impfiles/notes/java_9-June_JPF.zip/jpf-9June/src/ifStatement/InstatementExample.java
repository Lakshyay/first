package ifStatement;

public class InstatementExample {
public static void main(String[] args) {
	int a = 99,b=100,c=98;
	if(a<b) {
		 if(a<c) {
			 System.out.println("99 is less than 98");
		 }
		 else {
			 System.out.println("98 is less than 99");
		 }
	}
	else {
		System.out.println("99 is greater than 100");
	}
		
	
}
}
