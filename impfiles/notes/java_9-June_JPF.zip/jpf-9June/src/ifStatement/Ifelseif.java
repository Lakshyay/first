package ifStatement;

public class Ifelseif {
public static void main(String[] args) {
	double bal = 600;
	double amt = 500;
	
	if(amt<=0) {
		System.out.println("failed bcoz -ve");
	}
	else if(amt>bal) {
		System.out.println("failed bcoz bal is low");
	}
	//multiple else if statements
	else {
		System.out.println("successful");
	}
}
}
