package ifStatement;

public class SwitchExplanation {
public static void main(String[] args) {
	int choice = 2;
	
	switch(choice) {
	case 1: System.out.println("Sunday");
	break;
	case 2: System.out.println("Monday");
	break;
	case 3: System.out.println("Tuesday");
	break;
	default:
		System.out.println("exited from switch");
	}
}
}
