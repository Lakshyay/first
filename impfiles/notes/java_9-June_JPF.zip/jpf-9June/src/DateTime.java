import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateTime {
public static void main(String[] args) {
	LocalDateTime ob = LocalDateTime.now();
	
	System.out.println("Before Formatting"+ob);
	DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
	String f = ob.format(df);
	System.out.println(f);
}
}
