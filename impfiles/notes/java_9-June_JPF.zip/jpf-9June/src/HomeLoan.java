

	class HomeLoan extends Loan{
    HomeLoan(){
    	
    	System.out.println("Request for HomeLoan");
    }
	
//    HomeLoan(int x) {
//			super(x);
//			
//		}

	public static void main(String[] args){
        HomeLoan obh=new HomeLoan();
    }
}