
class Loan{
	int x;
//	Loan(){
//		System.out.println("Hi");
//	}
//    Loan(int x){
//        System.out.println("Request for loan");
//    }
}