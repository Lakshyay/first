package loops;

public class LoopsEx {
          public static void main(String[] args) {
//			int x = 0;
//			 while(x<0) {//1<3,2<3,3<3//false
//				 System.out.println(x);//1,//2
//				 x++;//1//2//3
//			 }
			 
//		for(int i = 0;i<5;i++) {//5<5//false
//			System.out.println(i);
//		}
			
		int y =10;
		do {
			System.out.println(y);
			y--;
			
		}while(y<=0);//false
		}
}
