package loops;

public class breakExp {
public static void main(String[] args) {
	for(int i = 0;i<5;i++) {
		if(i==3) {
//			break;//just comes out of the loop and after the loop the mention stms 
//			       //gets printed.t
			continue;//it will just send the control back then i will become 4 
			          
		}
		System.out.println(i);//skipped for i ==3;
	}
	System.out.println("p");
}
}
