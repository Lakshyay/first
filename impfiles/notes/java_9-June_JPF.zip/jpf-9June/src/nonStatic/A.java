package nonStatic;

public class A {
 int age=10;

public static void main(String[] args) {
	A a1 = new A();
	System.out.println(a1.age);
	a1.test();
//	age=20;
	a1.age = 20;
	System.out.println(a1.age);
}
public void test() {
	System.out.println("Hello");
}
}
