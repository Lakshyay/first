package enumsExa;

public enum Grades {
A,B,C,D,E;
}
