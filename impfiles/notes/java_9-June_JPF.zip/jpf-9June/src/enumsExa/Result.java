package enumsExa;

public class Result {
public void resultOfStudent(Grades grade) {
	switch(grade) {
	case A:
		System.out.println("has got 95+ marks");
		break;
	case B:
		System.out.println("has got 85+ marks");
		break;
	case C:
		System.out.println("has got 75+ marks");
		break;
	case D:
		System.out.println("has got 65+ marks");
		break;
	case E:
		System.out.println("has got 55+ marks");
		break;
	default:
		System.out.println("Student was absent");
	}
}
public static void main(String[] args) {
	Result s = new Result();
	s.resultOfStudent(Grades.E);
}
}
