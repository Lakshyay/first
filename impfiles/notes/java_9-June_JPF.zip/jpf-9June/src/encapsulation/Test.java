package encapsulation;

public class Test {
public static void main(String[] args) {
	Employee e = new Employee();
	
	
	e.setAge(22);
	e.setName("pragya");
	e.setCity("bangalore");
	
	System.out.println("Age is :"+e.getAge());
	System.out.println("Name is :"+e.getName());
	System.out.println("City is : "+ e.getCity());

}
}
