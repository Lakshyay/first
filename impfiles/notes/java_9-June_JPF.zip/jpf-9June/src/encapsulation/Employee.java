package encapsulation;

public class Employee {
public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
private int age;
private String name;
private String city;


public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}


}
