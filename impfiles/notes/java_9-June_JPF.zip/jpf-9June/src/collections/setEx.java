package collections;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;



public class setEx {
	public static void main(String[] args) {
//		Set<Integer> s = new LinkedHashSet();
		Set<Integer> s = new TreeSet();
		s.add(34);
		s.add(2);
		s.add(34);
		System.out.println(s.contains(34));
		System.out.println(s.isEmpty());
		System.out.println(s);
		s.clear();
	}


}
