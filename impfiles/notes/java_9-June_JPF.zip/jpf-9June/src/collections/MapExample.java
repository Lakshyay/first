package collections;

import java.util.*;

public class MapExample {
public static void main(String[] args) {
//	Map<String, Integer> m = new HashMap<>();
	
}
}
