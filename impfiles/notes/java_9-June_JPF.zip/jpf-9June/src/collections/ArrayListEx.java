package collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class ArrayListEx {
public static void main(String[] args) {
//	ArrayList<String> al = new ArrayList<>();
	LinkedList<String> al = new LinkedList<String>();
	al.add("avani");
	al.add("yash");
	System.out.println(al);
	al.add(1,"aryan");
	al.add(1,"Hina");
	System.out.println(al);
	al.add("lakshay");
	System.out.println(al);
	System.out.println(al.get(1));
	System.out.println(al.remove("Hina"));
//	System.out.println(al.remove(String.valueOf("Hina")));
	al.set(2, "Abhishek");
//	System.out.println(al);
//	al.clear();
	System.out.println(al);
	Iterator itr = al.iterator();
	while(itr.hasNext()) {
		System.out.println("Value of list"+ itr.next());
	}
	
	
	
}
}
