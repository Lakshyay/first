package collections;

import java.util.HashMap;
import java.util.Map;

public class AQ {
public static void main(String[] args) {
	Map<String,Integer> m = new HashMap<>();
	m.put("one", 1);
	m.put("Two", 2);
	m.put("three", 3);
	
//	for(Map.Entry<String, Integer> e : m.entrySet()) {
//		System.out.println(e);
//		System.out.println(e.getKey());
//		System.out.println(e.getValue());
//	}
	
	for(String n : m.keySet()) {
		System.out.println(n);
	}
	
	for(Integer b : m.values()) {
		System.out.println(b);
	}
}
}
