package collections;
import java.util.*;
public class StackEx {
public static void main(String[] args) {
//	Stack<Integer> stac = new Stack<>();
//	stac.push(1);
//	stac.push(2);
//	stac.push(4);
//	System.out.println(stac);
//	System.out.println(stac.peek());//last pushged element
//	stac.pop();
//	System.out.println(stac);
	
	
//	Queue<Integer> q = new LinkedList<Integer>();
//	q.offer(5);
//	q.offer(2);
//	q.offer(4);
//	System.out.println(q);
////	System.out.println(q.poll());
//	System.out.println(q.remove());
//	System.out.println("After removing "+ q);
	
	
//	PriorityQueue<Integer> pq = new PriorityQueue<Integer>(Comparator.reverseOrder());
//	pq.offer(32);
//	pq.offer(23);
//	pq.offer(13);
//	System.out.println(pq);
	
	
	ArrayDeque<Integer> adq = new ArrayDeque<Integer>();
	adq.offer(34);
	adq.offer(12);
	adq.offerFirst(11);
	adq.offerLast(67);
	adq.offer(23);
//	System.out.println(adq);
	System.out.println(adq.peekLast());
}
	
	
	
	
}
