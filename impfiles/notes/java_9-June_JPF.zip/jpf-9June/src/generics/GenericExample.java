package generics;

class G<T>{
	T value;
//	public void show() {
//		System.out.println(value.getClass().getName());
//		System.out.println(value);
//	}
	G(T x){
		this.value=x;
		System.out.println(value);
	}
}
public class GenericExample {
	public static void main(String[] args) {
//		G<Integer> g1 = new G<>();
//		  g1.value = 3;
//		  g1.show();
//		  
//		  G<String> g2 = new G<>();
//		  g2.value = "Str";
//		  g2.show();
		
		G<String> a1 = new G<>("abc");
		G<Integer> a2 = new G<>(100);
		G<Character> a3 = new G<>('a');
 
	}
  

}
